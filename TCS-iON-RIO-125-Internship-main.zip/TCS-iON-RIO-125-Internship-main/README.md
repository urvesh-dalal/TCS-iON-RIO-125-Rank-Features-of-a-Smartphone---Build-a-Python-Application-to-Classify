# Rank Features of a Smartphone 📱

## Project Overview
This project focuses on building a machine learning model to rank and predict important smartphone features using classification techniques.  
The goal is to train the model using labeled smartphone data and predict feature importance for new smartphone data entries.

## Project Structure
```
TCS-iON-RIO-125-Internship-main/
│
├── MobileTrain.csv          # Training dataset containing smartphone feature data
├── MobileTest.csv           # Test dataset for predictions
├── internship_smartphone.ipynb  # Jupyter notebook containing all code (EDA, model building, evaluation)
├── result.csv               # Prediction output generated from the test dataset
```

## Tools & Technologies
- Python 3.x
- Jupyter Notebook
- pandas
- scikit-learn
- matplotlib

## Setup Instructions 🚀
1. Clone or download this repository.
2. Open `internship_smartphone.ipynb` using Jupyter Notebook or VS Code with Jupyter extension.
3. Install required Python libraries if not already installed:
   ```bash
   pip install pandas scikit-learn matplotlib
   ```
4. Run all cells in the notebook to:
   - Load datasets
   - Preprocess data
   - Train the machine learning model
   - Predict smartphone rankings
   - Save results into `result.csv`

## How it Works
- Load the `MobileTrain.csv` file for model training.
- Analyze and preprocess the dataset.
- Train a classification model (Random Forest or similar) to rank smartphone features.
- Predict rankings for new data in `MobileTest.csv`.
- Save the final output in `result.csv`.

## Results
- The project outputs a CSV file (`result.csv`) containing the predicted ranks or classes for the smartphones based on the trained model.

## Future Enhancements
- Implement hyperparameter tuning for better model performance.
- Add feature scaling or normalization techniques.
- Create a web application for real-time smartphone ranking.
- Visualize feature importances dynamically.

## Author
- Internship Project by [Your Name]
- Under guidance of TCS-iON RIO Internship Program
